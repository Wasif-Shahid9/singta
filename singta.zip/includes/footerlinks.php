
   <script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="assets/js/plugins/meanmenu.min.js"></script>
    <script src="assets/js/plugins/swiper.min.js"></script>
    <script src="assets/js/plugins/wow.min.js"></script>
    <script src="assets/js/vendor/magnific-popup.min.js"></script>
    <script src="assets/js/vendor/isotope.pkgd.min.js"></script>
    <script src="assets/js/vendor/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <script src="assets/js/plugins/jarallax.min.js"></script>
    <script src="assets/js/vendor/ajax-form.js"></script>
    <script src="assets/js/plugins/easypie.js"></script>
    <script src="assets/js/plugins/headding-title.js"></script>
    <script src="assets/js/plugins/lenis.min.js"></script>
    <script src="assets/js/plugins/gsap.min.js"></script>
    <script src="assets/js/plugins/rs-anim-int.js"></script>
    <script src="assets/js/plugins/rs-scroll-trigger.min.js"></script>
    <script src="assets/js/plugins/rs-splitText.min.js"></script>
    <script src="assets/js/plugins/jquery.lettering.js"></script>
    <script src="assets/js/plugins/parallax-effect.min.js"></script>
    <!-- <script src="assets/js/plugins/jquery.appear.min.js"></script> -->
    <script src="assets/js/plugins/marquee.min.js"></script>
    <!-- <script src="assets/js/plugins/chart.umd.min.js"></script> -->
    <!-- <script src="assets/js/plugins/nouislider.min.js"></script> -->
    <script src="assets/js/vendor/purecounter.js"></script>
    <!-- <script src="assets/js/vendor/odometer.min.js"></script> -->
    <script src="assets/js/main.js"></script>
</body>



</html>